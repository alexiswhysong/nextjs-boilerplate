document.addEventListener("DOMContentLoaded", function() {
    const header = document.querySelectorAll(".header h3");

    header.forEach(title => {
        title.addEventListener("click", function() {
            // Change the text of the title
            this.textContent = "Something Else";
        });
    });
});
const details = document.querySelector('summary');

// toggle the 1ST instance of the stats
document.querySelector('button[data-toggle-btn]').addEventListener('click', (e) => {
  if (details.parentNode.getAttribute('open')) {
    details.parentNode.removeAttribute('open');
  }
  else {
    details.parentNode.setAttribute('open','open');    
  }
});

// duplicate the 1st item
document.querySelector('.duplicate').addEventListener('click', function(e) {
  const itemToClone = document.querySelector('.wrapper').cloneNode(true);
  document.body.appendChild(itemToClone);
});

// modify name of 1st item
document.querySelector('.modifytitle').addEventListener('click', function(e) {
  let name = prompt("New Sheetz Order...");
  if (name) {
    document.querySelector('.wrapper h3').innerText = name;
  }
});

// delete the last item
document.querySelector('#deletelastcard').addEventListener('click', function(e) {
  let wantsTo = confirm("Are you sure?");
  if (wantsTo) {
    if (document.querySelector('.wrapper:last-child') !== document.querySelector('.wrapper')) {
      document.querySelector('.wrapper:last-child').remove();      
    }
    else {
      alert("You Will Loose Your MTO");
    }
  }
});
// Select the button element and the heading element
const changeButton = document.getElementById('changeButton');
const myHeading = document.getElementById('myHeading');

// Add a click event listener to the button
